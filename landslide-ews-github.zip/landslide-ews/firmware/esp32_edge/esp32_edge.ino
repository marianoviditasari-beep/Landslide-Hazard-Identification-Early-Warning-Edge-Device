/*  EDGE 1 - ESP32 di lereng
 *  Sensor : soil moisture capacitive (GPIO34), rain sensor analog (GPIO35), MPU6050 (I2C 21/22)
 *  Output : buzzer (GPIO25), LED merah (GPIO26), LED hijau (GPIO27)
 *  Proses : (1) signal processing: moving average + ekstraksi fitur (tilt delta, rain accumulation 24 jam)
 *           (2) AI: Decision Tree (model.h) -> 0 Aman / 1 Waspada / 2 Bahaya
 *  Cloud  : MQTT (PubSubClient) -> broker; alarm lokal tetap jalan walau internet putus.
 *  Library: PubSubClient, Adafruit MPU6050, Adafruit Unified Sensor, ArduinoJson
 */
#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <ArduinoJson.h>
#include "model.h"

// ====== KONFIGURASI ======
const char* WIFI_SSID = "NAMA_WIFI";
const char* WIFI_PASS = "PASSWORD_WIFI";
const char* MQTT_HOST = "broker.hivemq.com";
const int   MQTT_PORT = 1883;
const char* NODE_ID   = "lereng01";           // ganti unik per kelompok agar tidak bentrok di broker publik
String TOPIC_DATA   = String("kel_longsor/") + NODE_ID + "/data";
String TOPIC_STATUS = String("kel_longsor/") + NODE_ID + "/status";

const int PIN_SOIL = 34, PIN_RAIN = 35, PIN_BUZZ = 25, PIN_LED_R = 26, PIN_LED_G = 27;
// Kalibrasi ADC (ukur sendiri: sensor di udara = KERING, dicelup air = BASAH)
const int SOIL_DRY = 3200, SOIL_WET = 1400;
const int RAIN_DRY = 4095, RAIN_WET = 1200;
const float RAIN_MMH_PER_PCT = 0.5f;          // kalibrasi kasar: 100% basah ~ 50 mm/jam
const unsigned long SAMPLE_MS = 1000, PUBLISH_MS = 5000;

Adafruit_MPU6050 mpu;
WiFiClient wifi; PubSubClient mqtt(wifi);

// ====== Moving average ======
template<int N> struct MA { float b[N] = {0}; int i = 0, n = 0; float sum = 0;
  float add(float v) { sum += v - b[i]; b[i] = v; i = (i + 1) % N; if (n < N) n++; return sum / n; } };
MA<10> maSoil, maRain, maTilt;

float baseRoll = 0, basePitch = 0, rainAcc24 = 0, vibRms = 0;
int risk = 0; unsigned long tSample = 0, tPub = 0;

float mapPct(int raw, int dry, int wet) { return constrain((float)(dry - raw) * 100.0f / (dry - wet), 0, 100); }

void calibrateTilt() {                         // posisi awal lereng = acuan 0 derajat
  float r = 0, p = 0; sensors_event_t a, g, t;
  for (int i = 0; i < 50; i++) { mpu.getEvent(&a, &g, &t);
    r += atan2(a.acceleration.y, a.acceleration.z) * 57.296f;
    p += atan2(-a.acceleration.x, sqrt(a.acceleration.y*a.acceleration.y + a.acceleration.z*a.acceleration.z)) * 57.296f;
    delay(20); }
  baseRoll = r / 50; basePitch = p / 50;
}

void setAlarm(int level) {
  digitalWrite(PIN_LED_G, level == 0); digitalWrite(PIN_LED_R, level > 0);
  if (level == 2) digitalWrite(PIN_BUZZ, (millis() / 300) % 2);     // beep cepat
  else if (level == 1) digitalWrite(PIN_BUZZ, (millis() % 2000) < 150); // beep sesekali
  else digitalWrite(PIN_BUZZ, LOW);
}

void connectWifi() { if (WiFi.status() == WL_CONNECTED) return;
  WiFi.begin(WIFI_SSID, WIFI_PASS); unsigned long t = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t < 5000) delay(200); }

void connectMqtt() { if (mqtt.connected() || WiFi.status() != WL_CONNECTED) return;
  String cid = String("esp32-") + NODE_ID;
  if (mqtt.connect(cid.c_str(), nullptr, nullptr, TOPIC_STATUS.c_str(), 1, true, "offline"))   // LWT
    mqtt.publish(TOPIC_STATUS.c_str(), "online", true); }

void setup() {
  Serial.begin(115200);
  pinMode(PIN_BUZZ, OUTPUT); pinMode(PIN_LED_R, OUTPUT); pinMode(PIN_LED_G, OUTPUT);
  Wire.begin(21, 22);
  if (!mpu.begin()) { Serial.println("MPU6050 tidak terdeteksi!"); while (1) delay(1000); }
  mpu.setAccelerometerRange(MPU6050_RANGE_4_G); mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  calibrateTilt();
  mqtt.setServer(MQTT_HOST, MQTT_PORT); mqtt.setBufferSize(512);
  connectWifi();
}

void loop() {
  connectWifi(); connectMqtt(); mqtt.loop();
  unsigned long now = millis();

  if (now - tSample >= SAMPLE_MS) {
    float dt_h = (now - tSample) / 3.6e6f; tSample = now;
    sensors_event_t a, g, t; mpu.getEvent(&a, &g, &t);

    // --- Signal processing: filter + ekstraksi fitur ---
    float soil = maSoil.add(mapPct(analogRead(PIN_SOIL), SOIL_DRY, SOIL_WET));
    float rainPct = maRain.add(mapPct(analogRead(PIN_RAIN), RAIN_DRY, RAIN_WET));
    float rainMmh = rainPct * RAIN_MMH_PER_PCT;
    rainAcc24 += rainMmh * dt_h; rainAcc24 *= (1.0f - dt_h / 24.0f);  // leaky integrator ~ akumulasi 24 jam
    float roll = atan2(a.acceleration.y, a.acceleration.z) * 57.296f;
    float pitch = atan2(-a.acceleration.x, sqrt(a.acceleration.y*a.acceleration.y + a.acceleration.z*a.acceleration.z)) * 57.296f;
    float tiltDelta = maTilt.add(sqrt(sq(roll - baseRoll) + sq(pitch - basePitch)));
    float aMag = sqrt(sq(a.acceleration.x) + sq(a.acceleration.y) + sq(a.acceleration.z)) / 9.81f;
    vibRms = 0.9f * vibRms + 0.1f * fabs(aMag - 1.0f);

    // --- AI: Decision Tree (data fusion 5 fitur) ---
    float f[5] = {soil, rainMmh, rainAcc24, tiltDelta, vibRms};
    risk = predict_risk(f);

    if (now - tPub >= PUBLISH_MS) { tPub = now;
      StaticJsonDocument<256> d;
      d["node"] = NODE_ID; d["soil"] = soil; d["rain_mmh"] = rainMmh; d["rain_acc24"] = rainAcc24;
      d["tilt"] = tiltDelta; d["vib"] = vibRms; d["risk"] = risk;
      char buf[256]; serializeJson(d, buf);
      if (mqtt.connected()) mqtt.publish(TOPIC_DATA.c_str(), buf);
      Serial.println(buf);
    }
  }
  setAlarm(risk);   // alarm lokal: independen dari internet
}
