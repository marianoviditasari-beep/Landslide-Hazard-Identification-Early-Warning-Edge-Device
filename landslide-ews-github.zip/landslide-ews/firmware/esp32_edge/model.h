// AUTO-GENERATED oleh ai/train_model.py - jangan edit manual
#pragma once
// f[] = {soil_pct, rain_mmh, rain_acc24, tilt_delta, vib}
// return: 0=Aman 1=Waspada 2=Bahaya
inline int predict_risk(const float *f) {
  if (f[2] <= 123.7706f) {
    if (f[0] <= 63.5059f) {
      if (f[2] <= 76.9497f) {
        if (f[3] <= 10.8139f) {
          if (f[0] <= 52.9068f) {
            if (f[4] <= 0.1267f) {
              if (f[3] <= 6.7046f) {
                return 0;
              } else {
                return 0;
              }
            } else {
              if (f[0] <= 47.4629f) {
                return 0;
              } else {
                return 0;
              }
            }
          } else {
            if (f[2] <= 63.8721f) {
              if (f[4] <= 0.1994f) {
                return 0;
              } else {
                return 0;
              }
            } else {
              return 1;
            }
          }
        } else {
          if (f[0] <= 37.1910f) {
            if (f[0] <= 21.2340f) {
              return 0;
            } else {
              return 0;
            }
          } else {
            if (f[4] <= 0.0423f) {
              return 1;
            } else {
              return 1;
            }
          }
        }
      } else {
        if (f[0] <= 45.5658f) {
          if (f[3] <= 9.2743f) {
            if (f[4] <= 0.1999f) {
              if (f[1] <= 26.4104f) {
                return 0;
              } else {
                return 0;
              }
            } else {
              return 1;
            }
          } else {
            return 1;
          }
        } else {
          if (f[1] <= 12.2884f) {
            if (f[2] <= 103.8576f) {
              if (f[0] <= 52.1687f) {
                return 0;
              } else {
                return 1;
              }
            } else {
              return 1;
            }
          } else {
            if (f[3] <= 1.1187f) {
              return 1;
            } else {
              if (f[4] <= 0.0337f) {
                return 1;
              } else {
                return 1;
              }
            }
          }
        }
      }
    } else {
      if (f[3] <= 6.3540f) {
        if (f[2] <= 31.3338f) {
          if (f[0] <= 85.3983f) {
            if (f[4] <= 0.1911f) {
              if (f[0] <= 76.0673f) {
                return 0;
              } else {
                return 0;
              }
            } else {
              return 1;
            }
          } else {
            if (f[3] <= 0.2013f) {
              return 0;
            } else {
              if (f[0] <= 91.2138f) {
                return 1;
              } else {
                return 1;
              }
            }
          }
        } else {
          if (f[0] <= 74.1017f) {
            if (f[2] <= 56.0190f) {
              if (f[4] <= 0.0562f) {
                return 0;
              } else {
                return 1;
              }
            } else {
              if (f[1] <= 6.4049f) {
                return 0;
              } else {
                return 1;
              }
            }
          } else {
            if (f[4] <= 0.3549f) {
              if (f[2] <= 116.7312f) {
                return 1;
              } else {
                return 1;
              }
            } else {
              return 1;
            }
          }
        }
      } else {
        if (f[2] <= 55.6697f) {
          if (f[4] <= 0.0566f) {
            if (f[2] <= 45.1242f) {
              if (f[2] <= 11.4578f) {
                return 1;
              } else {
                return 1;
              }
            } else {
              return 1;
            }
          } else {
            return 1;
          }
        } else {
          if (f[0] <= 82.6004f) {
            return 1;
          } else {
            return 2;
          }
        }
      }
    }
  } else {
    if (f[0] <= 62.5729f) {
      if (f[0] <= 40.3030f) {
        if (f[2] <= 186.3085f) {
          if (f[0] <= 36.5219f) {
            if (f[1] <= 20.0487f) {
              if (f[3] <= 2.1458f) {
                return 0;
              } else {
                return 0;
              }
            } else {
              return 1;
            }
          } else {
            return 1;
          }
        } else {
          if (f[4] <= 0.0881f) {
            if (f[0] <= 14.1085f) {
              return 1;
            } else {
              if (f[1] <= 17.6285f) {
                return 1;
              } else {
                return 1;
              }
            }
          } else {
            return 1;
          }
        }
      } else {
        if (f[2] <= 201.6018f) {
          if (f[3] <= 5.1410f) {
            if (f[2] <= 141.8416f) {
              if (f[3] <= 0.7823f) {
                return 1;
              } else {
                return 1;
              }
            } else {
              if (f[2] <= 150.3809f) {
                return 1;
              } else {
                return 1;
              }
            }
          } else {
            return 2;
          }
        } else {
          if (f[1] <= 31.3251f) {
            if (f[3] <= 2.8367f) {
              if (f[4] <= 0.0394f) {
                return 1;
              } else {
                return 2;
              }
            } else {
              return 2;
            }
          } else {
            return 2;
          }
        }
      }
    } else {
      if (f[2] <= 182.8212f) {
        if (f[0] <= 83.2142f) {
          if (f[3] <= 2.4258f) {
            if (f[1] <= 22.2979f) {
              if (f[4] <= 0.0195f) {
                return 1;
              } else {
                return 1;
              }
            } else {
              return 2;
            }
          } else {
            return 2;
          }
        } else {
          if (f[3] <= 2.7955f) {
            if (f[2] <= 135.8422f) {
              return 1;
            } else {
              if (f[0] <= 88.4066f) {
                return 2;
              } else {
                return 2;
              }
            }
          } else {
            return 2;
          }
        }
      } else {
        if (f[2] <= 213.9343f) {
          if (f[0] <= 77.6392f) {
            return 2;
          } else {
            return 2;
          }
        } else {
          if (f[0] <= 67.0039f) {
            return 2;
          } else {
            if (f[4] <= 0.0098f) {
              return 2;
            } else {
              return 2;
            }
          }
        }
      }
    }
  }
}
