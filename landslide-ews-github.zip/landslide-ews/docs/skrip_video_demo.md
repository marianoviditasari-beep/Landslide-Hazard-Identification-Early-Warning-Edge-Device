# Skrip Video Demo (target 3-4 menit)

**Persiapan**: prototipe di atas papan/miniatur lereng (kotak tanah), ESP32 menyala, HP Android menjalankan `android_edge.py`, laptop menampilkan dashboard. Rekam layar laptop + kamera HP terpisah, gabungkan di CapCut.

| Waktu | Visual | Narasi |
|---|---|---|
| 0:00-0:20 | Judul + anggota | "Kami kelompok X. Proyek kami: Landslide Hazard Identification & Early Warning Edge Device." |
| 0:20-0:50 | Foto/slide masalah longsor | "Longsor sering terjadi saat hujan lama membuat tanah jenuh. Peringatan dini murah di lereng masih minim." |
| 0:50-1:20 | Close-up hardware + diagram arsitektur | "Edge 1 ESP32 membaca soil moisture, rain sensor, MPU6050. Edge 2 HP Android menerima data via MQTT dan memvalidasi alert." |
| 1:20-1:40 | Dashboard status AMAN (hijau), LED hijau | "Kondisi awal: tanah kering, status AMAN." |
| 1:40-2:20 | Siram air ke tanah + rain sensor | "Kami simulasikan hujan. Kelembapan dan akumulasi hujan naik, AI mengubah status ke WASPADA, LED merah dan buzzer beep pelan." |
| 2:20-3:00 | Miringkan prototipe, grafik tilt naik | "Kami miringkan lereng. Fusi sensor menaikkan risiko ke BAHAYA, buzzer cepat, notifikasi + getar + suara muncul di HP, Telegram masuk." |
| 3:00-3:25 | Matikan WiFi/hotspot | "Saat internet putus, alarm lokal ESP32 tetap berfungsi." |
| 3:25-3:50 | Slide GitHub + QR + penutup | "Kode lengkap ada di GitHub. Terima kasih." |

**Checklist rekaman**: terlihat Serial Monitor/dashboard dan HP dalam satu frame; tiap anggota bicara minimal sekali; durasi sesuai ketentuan dosen.
