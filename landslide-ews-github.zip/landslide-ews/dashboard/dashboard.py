"""Dashboard realtime (Streamlit).  Jalankan: streamlit run dashboard/dashboard.py"""
import json, threading, collections, time
import pandas as pd, streamlit as st, paho.mqtt.client as mqtt

BROKER, NODE = "broker.hivemq.com", "lereng01"
NAMA, WARNA = ["AMAN", "WASPADA", "BAHAYA"], ["#2e9e5b", "#e6a100", "#d62828"]

@st.cache_resource
def start():
    buf = collections.deque(maxlen=500)
    def on_msg(c, u, m):
        if m.topic.endswith("/data"): buf.append({**json.loads(m.payload), "t": time.strftime("%H:%M:%S")})
    c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1) if hasattr(mqtt, "CallbackAPIVersion") else mqtt.Client()
    c.on_connect = lambda c, *a: c.subscribe(f"kel_longsor/{NODE}/data")
    c.on_message = on_msg; c.connect(BROKER, 1883, 60); threading.Thread(target=c.loop_forever, daemon=True).start()
    return buf

buf = start()
st.set_page_config(page_title="Landslide EWS", layout="wide")
st.title("⛰️ Landslide Early Warning - Dashboard")
if not buf: st.info("Menunggu data dari ESP32..."); time.sleep(2); st.rerun()
df = pd.DataFrame(buf); last = df.iloc[-1]
st.markdown(f"<div style='padding:20px;border-radius:12px;background:{WARNA[int(last.risk)]};color:white;font-size:32px;text-align:center'>STATUS: {NAMA[int(last.risk)]}</div>", unsafe_allow_html=True)
c1, c2, c3, c4 = st.columns(4)
c1.metric("Kelembapan tanah", f"{last.soil:.0f}%"); c2.metric("Hujan 24 jam", f"{last.rain_acc24:.1f} mm")
c3.metric("Kemiringan", f"{last.tilt:.1f}°"); c4.metric("Getaran", f"{last.vib:.3f} g")
st.line_chart(df.set_index("t")[["soil", "rain_mmh", "tilt"]])
st.dataframe(df[df.risk > 0].tail(20), use_container_width=True)
time.sleep(3); st.rerun()
