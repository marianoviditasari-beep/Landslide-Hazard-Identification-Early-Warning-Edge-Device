"""Training Decision Tree untuk klasifikasi risiko longsor + export ke C (ESP32).
Fitur: soil_pct, rain_mmh, rain_acc24, tilt_delta, vib
Kelas : 0=Aman, 1=Waspada, 2=Bahaya
Catatan: dataset SINTETIS berbasis aturan (bobot risiko tanah-hujan-kemiringan).
Ganti dengan data hasil logging prototipe bila sudah ada."""
import numpy as np, pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix

FEATS = ["soil_pct", "rain_mmh", "rain_acc24", "tilt_delta", "vib"]
LABELS = ["Aman", "Waspada", "Bahaya"]
rng = np.random.default_rng(42)

def make_data(n=6000):
    soil = rng.uniform(10, 100, n); rain = rng.gamma(1.2, 8, n).clip(0, 60)
    acc = (rain * rng.uniform(2, 14, n)).clip(0, 250)
    tilt = np.abs(rng.normal(0, 2, n)) + (rng.random(n) < .12) * rng.uniform(2, 14, n)
    vib = np.abs(rng.normal(0.03, 0.02, n)) + (rng.random(n) < .1) * rng.uniform(.05, .5, n)
    score = 0.35*soil/100 + 0.15*rain/60 + 0.25*acc/250 + 0.15*tilt/15 + 0.10*vib/0.5
    score += rng.normal(0, 0.03, n)
    y = np.where(score > 0.55, 2, np.where(score > 0.35, 1, 0))
    return pd.DataFrame(np.c_[soil, rain, acc, tilt, vib], columns=FEATS).assign(label=y)

def tree_to_c(clf):
    t = clf.tree_; out = []
    def rec(node, d):
        pad = "  " * d
        if t.feature[node] == -2:
            out.append(f"{pad}return {int(np.argmax(t.value[node]))};")
        else:
            out.append(f"{pad}if (f[{t.feature[node]}] <= {t.threshold[node]:.4f}f) {{")
            rec(t.children_left[node], d + 1); out.append(f"{pad}}} else {{")
            rec(t.children_right[node], d + 1); out.append(f"{pad}}}")
    rec(0, 1)
    return ("// AUTO-GENERATED oleh ai/train_model.py - jangan edit manual\n#pragma once\n"
            "// f[] = {soil_pct, rain_mmh, rain_acc24, tilt_delta, vib}\n"
            "// return: 0=Aman 1=Waspada 2=Bahaya\n"
            "inline int predict_risk(const float *f) {\n" + "\n".join(out) + "\n}\n")

if __name__ == "__main__":
    df = make_data(); df.to_csv("ai/dataset_sintetis.csv", index=False)
    Xtr, Xte, ytr, yte = train_test_split(df[FEATS], df.label, test_size=.25, stratify=df.label, random_state=1)
    clf = DecisionTreeClassifier(max_depth=7, min_samples_leaf=15, class_weight="balanced", random_state=1).fit(Xtr, ytr)
    pred = clf.predict(Xte)
    print(classification_report(yte, pred, target_names=LABELS, digits=3))
    print(confusion_matrix(yte, pred))
    print("Feature importance:", dict(zip(FEATS, clf.feature_importances_.round(3))))
    open("firmware/esp32_edge/model.h", "w").write(tree_to_c(clf))
    print("model.h dibuat")
