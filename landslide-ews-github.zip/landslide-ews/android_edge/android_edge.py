"""EDGE 2 - HP Android (Termux). Jalankan:  pkg install python termux-api && pip install paho-mqtt requests
Fungsi: subscribe MQTT -> validasi 2 tahap (3 pembacaan berturut-turut) -> notifikasi/getar/suara di HP,
        kirim alert Telegram, simpan log CSV lokal (tetap bekerja walau dashboard mati)."""
import json, csv, os, time, subprocess, collections, requests
import paho.mqtt.client as mqtt

BROKER, PORT = "broker.hivemq.com", 1883
NODE = "lereng01"
TG_TOKEN, TG_CHAT = os.getenv("TG_TOKEN", ""), os.getenv("TG_CHAT", "")   # opsional
NAMA = ["AMAN", "WASPADA", "BAHAYA"]
hist = collections.deque(maxlen=3); last_alert = 0

def sh(*cmd):
    try: subprocess.Popen(cmd)
    except FileNotFoundError: print("(termux-api tidak ada):", cmd[0])

def alert(level, d):
    msg = f"[{NAMA[level]}] Lereng {NODE}\nTanah {d['soil']:.0f}% | Hujan24j {d['rain_acc24']:.1f}mm | Miring {d['tilt']:.1f}°"
    sh("termux-notification", "-t", f"STATUS {NAMA[level]}", "-c", msg, "--priority", "max")
    if level == 2:
        sh("termux-vibrate", "-d", "2000"); sh("termux-tts-speak", "Peringatan! Bahaya longsor")
    if TG_TOKEN:
        try: requests.post(f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage", data={"chat_id": TG_CHAT, "text": msg}, timeout=5)
        except Exception as e: print("Telegram gagal:", e)

def on_connect(c, u, f, rc, *a):
    c.subscribe(f"kel_longsor/{NODE}/#"); print("Terhubung ke broker, menunggu data...")

def on_message(c, u, m):
    global last_alert
    if m.topic.endswith("/status"): print("Status node:", m.payload.decode()); return
    d = json.loads(m.payload); hist.append(d["risk"])
    new = not os.path.exists("log_edge2.csv")
    with open("log_edge2.csv", "a", newline="") as f:
        w = csv.writer(f)
        if new: w.writerow(["ts", "soil", "rain_mmh", "rain_acc24", "tilt", "vib", "risk"])
        w.writerow([int(time.time()), d["soil"], d["rain_mmh"], d["rain_acc24"], d["tilt"], d["vib"], d["risk"]])
    level = min(hist) if len(hist) == 3 else 0          # tahap 2: harus konsisten 3x -> kurangi alarm palsu
    print(time.strftime("%H:%M:%S"), NAMA[d["risk"]], "| terkonfirmasi:", NAMA[level])
    if level > 0 and time.time() - last_alert > 60: last_alert = time.time(); alert(level, d)

c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1) if hasattr(mqtt, "CallbackAPIVersion") else mqtt.Client()
c.on_connect, c.on_message = on_connect, on_message
c.connect(BROKER, PORT, 60); c.loop_forever()
